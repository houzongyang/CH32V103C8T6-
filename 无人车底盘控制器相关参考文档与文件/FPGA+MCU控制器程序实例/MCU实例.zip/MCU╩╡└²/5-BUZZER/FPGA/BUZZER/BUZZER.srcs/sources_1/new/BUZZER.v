`timescale 1 ps/ 1 ps
//////////////////////////////////////////////////////////////////////////////////
// Company:
// Engineer:
//
// Create Date: 03-13-2023 10:15:53
// Design Name:
// Module Name: BUZZER
// Project Name:
// Target Devices:
// Tool Versions:
// Description:
//
// Dependencies:
//
// Revision:
// Additional Comments:
//
//////////////////////////////////////////////////////////////////////////////////


module BUZZER(
	input				sys_clk,
	input     			i_buzzer_PB9,
	output              o_buzzer_N1

    );
assign o_buzzer_N1 = i_buzzer_PB9;
endmodule
