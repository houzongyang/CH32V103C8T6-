`timescale 1 ps/ 1 ps
//////////////////////////////////////////////////////////////////////////////////
// Company:
// Engineer:
//
// Create Date: 02-13-2023 16:18:27
// Design Name:
// Module Name: Motor
// Project Name:
// Target Devices:
// Tool Versions:
// Description:
//
// Dependencies:
//
// Revision:
// Additional Comments:
//
//////////////////////////////////////////////////////////////////////////////////


module Motor(
	input			sys_clk,
	input 			i_PWM_PB8,
	input 			i_PWM_PA4,
	output			o_motor_IN1A,
	output			o_motor_IN1B
    );
	
assign  o_motor_IN1A=i_PWM_PB8;
assign  o_motor_IN1B=i_PWM_PA4;
	
endmodule
