`timescale 1 ps/ 1 ps
//////////////////////////////////////////////////////////////////////////////////
// Company:
// Engineer:
//
// Create Date: 02-09-2023 14:58:22
// Design Name:
// Module Name: LED
// Project Name:
// Target Devices:
// Tool Versions:
// Description:
//
// Dependencies:
//
// Revision:
// Additional Comments:
//
//////////////////////////////////////////////////////////////////////////////////


module LED(
    input                   sys_clk  , 
    input   wire            led_PA9_mcu,
	output  wire            led_N20_fpga
    );
assign led_N20_fpga = led_PA9_mcu;

endmodule
