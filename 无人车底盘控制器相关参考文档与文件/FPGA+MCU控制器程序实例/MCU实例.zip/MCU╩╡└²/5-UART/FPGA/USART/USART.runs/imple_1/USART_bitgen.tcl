cd   "C:/Program Files (x86)/eHiWay/eLinx2.1/bin/shell/bin"
set tclFile  "C:/Program Files (x86)/eHiWay/eLinx2.1/bin/shell/bin/run_bitgen.tcl"
set dir "C:/Users/1/Desktop/USART"
set prj USART
set topEntity USART
set seriesName "eHiChip6"
set deviceName EQ6HL130
set packageName CSG484_H
set ImpleName imple_1
source $tclFile
run_bitgen $dir $prj $topEntity $seriesName $deviceName $packageName $ImpleName
exit 0
