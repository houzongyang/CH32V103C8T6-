`timescale 1 ps/ 1 ps
//////////////////////////////////////////////////////////////////////////////////
// Company:
// Engineer:
//
// Create Date: 03-15-2023 16:36:28
// Design Name:
// Module Name: USART
// Project Name:
// Target Devices:
// Tool Versions:
// Description:
//
// Dependencies:
//
// Revision:
// Additional Comments:
//
//////////////////////////////////////////////////////////////////////////////////


module USART(
	input           i_clk,           //�ⲿ50Mʱ��
	//MCU UART2
	input  	PA2,
	output 	PA3,

	//uart3�ӿ�  UART_TTL
	input           i_uart3_rxd,    //���ڽ��ն˿�
	output          o_uart3_txd    //���ڷ��Ͷ˿�

    );
assign  PA3=i_uart3_rxd;
assign  o_uart3_txd=PA2;
endmodule
