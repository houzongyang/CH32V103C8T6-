`timescale 1 ps/ 1 ps
//////////////////////////////////////////////////////////////////////////////////
// Company:
// Engineer:
//
// Create Date: 02-13-2023 16:10:35
// Design Name:
// Module Name: Servo
// Project Name:
// Target Devices:
// Tool Versions:
// Description:
//
// Dependencies:
//
// Revision:
// Additional Comments:
//
//////////////////////////////////////////////////////////////////////////////////


module Servo(
	input				sys_clk,
	input     			i_servo_PB4,
	output              o_servo_L4
    );
assign o_servo_L4 = i_servo_PB4;
endmodule
