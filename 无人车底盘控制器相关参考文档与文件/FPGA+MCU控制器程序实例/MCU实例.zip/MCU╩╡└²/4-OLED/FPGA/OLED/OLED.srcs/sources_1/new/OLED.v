`timescale 1 ps/ 1 ps
//////////////////////////////////////////////////////////////////////////////////
// Company:
// Engineer:
//
// Create Date: 02-14-2023 09:34:34
// Design Name:
// Module Name: OLED
// Project Name:
// Target Devices:
// Tool Versions:
// Description:
//
// Dependencies:
//
// Revision:
// Additional Comments:
//
//////////////////////////////////////////////////////////////////////////////////


module OLED(
	input           sys_clk, 
	input 			i_SCL_PB6,
	input 			i_SDA_PB7,
	output			o_SCL1,
	output			o_SDA1
    );

assign  o_SCL1=i_SCL_PB6;
assign  o_SDA1=i_SDA_PB7;
endmodule
