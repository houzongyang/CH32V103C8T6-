cd   "C:/Program Files (x86)/eHiWay/eLinx2.1/bin/shell/bin"
set tclFile  "C:/Program Files (x86)/eHiWay/eLinx2.1/bin/shell/bin/run_pack.tcl"
set dir "C:/Users/1/Desktop/jiaocheng/uart_test"
set prj uart_test
set topEntity uart_test
set seriesName "eHiChip6"
set deviceName "EQ6HL130"
set synthName synth_1
source $tclFile
run_pack $dir $prj $topEntity $seriesName $deviceName $synthName
exit 0
