cd   "C:/Program Files (x86)/eHiWay/eLinx2.1/bin/shell/bin"
set tclFile  "C:/Program Files (x86)/eHiWay/eLinx2.1/bin/shell/bin/run_pack.tcl"
set dir "C:/Users/1/Desktop/jiaocheng/pll_test"
set prj pll_test
set topEntity pll_test
set seriesName "eHiChip6"
set deviceName "EQ6HL130"
set synthName synth_2
source $tclFile
run_pack $dir $prj $topEntity $seriesName $deviceName $synthName
exit 0
