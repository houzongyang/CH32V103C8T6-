                     
module pll_test(
input       sys_clk,
input       rst_n,
output      clk_out           
);


wire        locked;

/////////////////////PLL IP call////////////////////////////
clk_wiz_0 clk_wiz_0_inst
(// Clock in ports
.inclk0(sys_clk),            // IN 50Mhz
// Clock out ports
.c0(),                // OUT 200Mhz
.c1(),               // OUT 100Mhz
.c2(),              // OUT 50Mhz
.c3(clk_out),    // OUT 25Mhz	 
// Status and control signals	 
.areset(~rst_n),        // RESET IN
.locked(locked)	
);     // OUT
endmodule
