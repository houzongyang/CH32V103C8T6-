`timescale 1ns / 1ps                       
//================================================================================
//  Revision History:
 //  Date          By            Revision    Change Description
//--------------------------------------------------------------------------------
//  2020/09/09     ANDY         1.0         Original
//*******************************************************************************/
//////////////////////////////////////////////////////////////////////////////////
module pll_test(
input       sys_clk,
input       rst_n,
output      clk_out           //pll clock output J8_Pin3
);


wire        locked;

/////////////////////PLL IP call////////////////////////////
clk_wiz_0 clk_wiz_0_inst
(// Clock in ports
.inclk0(sys_clk),            // IN 50Mhz
// Clock out ports
.c0(),                // OUT 200Mhz
.c1(),               // OUT 100Mhz
.c2(),              // OUT 50Mhz
.c3(clk_out ),    // OUT 25Mhz	 
// Status and control signals	 
.areset(~rst_n),        // RESET IN
.locked(locked)	
);     // OUT
endmodule
