cd   "C:/Program Files (x86)/eLinx2.0/bin/shell/bin"
set tclFile  "C:/Program Files (x86)/eLinx2.0/bin/shell/bin/run_route.tcl"
set dir "C:/WORK20200515/EQ6HL130_DEMO_1V0/EQ6HL130_CD/pll_test"
set prj pll_test
set topEntity pll_test
set seriesName "eHiChip6"
set deviceName EQ6HL130
set packageName CSG484
set synthName synth_1
set ImpleName imple_1
source $tclFile
run_route $dir $prj $topEntity $seriesName $deviceName $packageName $synthName $ImpleName
exit 0
