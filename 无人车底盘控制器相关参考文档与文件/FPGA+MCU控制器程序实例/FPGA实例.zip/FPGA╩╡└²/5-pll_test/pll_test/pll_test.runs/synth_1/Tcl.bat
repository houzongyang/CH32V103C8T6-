C:
	cd\
	cd /d "C:/WORK20200515/EQ6HL130_DEMO_1V0/EQ6HL130_CD/pll_test"
	"C:/Program Files (x86)/eLinx2.0/bin/Passkey/bin/quartus_map.exe" --read_settings_files=on --write_settings_files=off pll_test
	"C:/Program Files (x86)/eLinx2.0/bin/Passkey/bin/quartus_fit.exe" pll_test --set ROUTING_BACK_ANNOTATION_MODE=NORMAL
	"C:/Program Files (x86)/eLinx2.0/bin/Passkey/bin/quartus_cdb.exe" pll_test -c pll_test --vqm="C:/WORK20200515/EQ6HL130_DEMO_1V0/EQ6HL130_CD/pll_test/pll_test.runs/synth_1/pll_test.vqm"
	"C:/Program Files (x86)/eLinx2.0/bin/Passkey/bin/quartus_cdb.exe" pll_test --back_annotate=routing
	"C:/Program Files (x86)/eLinx2.0/bin/Passkey/bin/quartus_eda.exe" --read_settings_files=off --write_settings_files=off pll_test -c pll_test
