/********************************** (C) COPYRIGHT *******************************
 * File Name          : ch32v10x_it.h
 * Author             : WCH
 * Version            : V1.0.0
 * Date               : 2020/04/30
 * Description        : This file contains the headers of the interrupt handlers.
 *********************************************************************************
 * Copyright (c) 2021 Nanjing Qinheng Microelectronics Co., Ltd.
 * Attention: This software (modified or not) and binary are used for 
 * microcontroller manufactured by Nanjing Qinheng Microelectronics.
 *******************************************************************************/
#ifndef __CH32V10x_IT_H
#define __CH32V10x_IT_H

#include "debug.h"

#endif /* __CH32V10x_IT_H */
